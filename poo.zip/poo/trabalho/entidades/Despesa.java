package entidades;

public abstract class Despesa {

    public Despesa() {
    
    }


    public abstract void calcularImposto();
}