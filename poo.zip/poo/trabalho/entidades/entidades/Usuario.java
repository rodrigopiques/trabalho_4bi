package entidades;

public class Usuario {
    private String login;
    private String senhaCriptografada;
    
 
    public Usuario(String login, String senha) {
        this.login = login;
        this.senhaCriptografada = senha; 
    }

    
    public String getLogin() {
        return login;
    }
    
    
}