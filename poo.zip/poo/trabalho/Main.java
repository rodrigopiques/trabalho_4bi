import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("🚀 Sistema de Controle de Despesas 🚀");
        exibirMenuPrincipal();
    }

    private static void exibirMenuPrincipal() {
        int opcao = -1;
        while (opcao != 7) {
            System.out.println("\n--- MENU PRINCIPAL ---");
            System.out.println("1. Entrar Despesa");
            System.out.println("2. Anotar Pagamento");
            System.out.println("3. Listar Despesas em Aberto no período");
            System.out.println("4. Listar Despesas Pagas no período");
            System.out.println("5. Gerenciar Tipos de Despesa");
            System.out.println("6. Gerenciar Usuários");
            System.out.println("7. Sair");
            System.out.print("Escolha uma opção: ");

            if (scanner.hasNextInt()) {
                opcao = scanner.nextInt();
                scanner.nextLine(); 

                switch (opcao) {
                    case 1:
                        System.out.println("\n[FUNCIONALIDADE 1]: Entrar Despesa - Apenas exibindo a mensagem inicial.");
                       
                        break;
                    case 2:
                        System.out.println("\n[FUNCIONALIDADE 2]: Anotar Pagamento - Apenas exibindo a mensagem inicial.");
                       
                        break;
                    case 3:
                        System.out.println("\n[FUNCIONALIDADE 3]: Listar Despesas em Aberto - Apenas exibindo a mensagem inicial.");
                        break;
                    case 4:
                        System.out.println("\n[FUNCIONALIDADE 4]: Listar Despesas Pagas - Apenas exibindo a mensagem inicial.");
                        break;
                    case 5:
                        System.out.println("\n[FUNCIONALIDADE 5]: Gerenciar Tipos de Despesa - Apenas exibindo a mensagem inicial.");
                        break;
                    case 6:
                        System.out.println("\n[FUNCIONALIDADE 6]: Gerenciar Usuários - Apenas exibindo a mensagem inicial.");
                        break;
                    case 7:
                        System.out.println("\nSaindo do sistema. Até logo!");
                        break;
                    default:
                        System.out.println("\nOpção inválida. Por favor, escolha um número de 1 a 7.");
                }
            } else {
                System.out.println("\nEntrada inválida. Digite um número.");
                scanner.nextLine(); 
                opcao = -1; 
            }
        }
    }
}